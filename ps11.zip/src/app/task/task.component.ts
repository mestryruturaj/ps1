import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { CommonService } from '../services/common.service';
import { Task } from '../model/task.interface';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.scss']
})
export class TaskComponent implements OnInit {
  editTaskForm : FormGroup | any ;
  task: Task | any;

  // Property binding of task constraints
  @Input() name: string = "";
  @Input() description: string = "";
  @Input() taskStatus: string = "";
  @Input() created :Date | any;
  @Input() index: number = -1;
  showTimeStamp : any;

  formVisible:boolean = false;

  constructor(private _cs: CommonService) { }

  // ngOnInit : Convert date object to timestamp. Initializes FormGroup
  ngOnInit(): void {
    this.showTimeStamp = (this.created as Date).getTime()
    this.editTaskForm = new FormGroup({
      'name' : new FormControl(this.name),
      'description': new FormControl(this.description),
      'taskStatus': new FormControl(this.taskStatus),
    });
  }

  // Shows Edit Form
  onEdit(){
    this.formVisible = true;
  }


  // onEditTask :
  // 1. Creates task object
  // 2. Calls method on common service to edit given task
  onEditTask(){
    this.task = {
      'name' : this.editTaskForm.value.name,
      'description': this.editTaskForm.value.description,
      'taskStatus': this.editTaskForm.value.taskStatus,
      'created' : this.created
    }
    this._cs.editTask(this.index, this.taskStatus, this.task);
  }

  // onCancel : Closes form display
  onCancel(){
    this.formVisible = false;
  }

}
