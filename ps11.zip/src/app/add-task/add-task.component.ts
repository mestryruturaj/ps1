import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Task } from '../model/task.interface';
import { CommonService } from '../services/common.service';


@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.scss']
})
export class AddTaskComponent implements OnInit {
  // Declaring FormGroup Object.
  // Declaring Task Object.
  addTaskForm:FormGroup | any;
  task!:Task;
  taskGenerated = false;

  //
  // Injecting Common Service
  constructor(private _cs:CommonService) { }

  //
  // ngOnInit :
  // 1. Initializing FormGroup Object.
  // 2. Initializing Task Object.
  ngOnInit(): void {
    this.addTaskForm = new FormGroup({
      'name' : new FormControl('', Validators.required),
      'description': new FormControl('', Validators.required),
      'taskStatus': new FormControl('Open'),
    });
    this.task = this.addTaskForm.value;
  }

  //
  // Getters
  get name() {return this.addTaskForm.get('name')};
  get description() {return this.addTaskForm.get('description')};

  //
  // onAddTask :
  // 1. Sets values to task object constraints
  // 2. Calling methods from Common Services to add task
  onAddTask(){
    this.task = {
      name : this.addTaskForm.value.name,
      description: this.addTaskForm.value.description,
      taskStatus: this.addTaskForm.value.taskStatus,
      created : new Date()
    }
    this._cs.addTask(this.task);
    this.taskGenerated = true;
    setTimeout(()=>{
      this.taskGenerated = false;
    },2000)
  }
}
