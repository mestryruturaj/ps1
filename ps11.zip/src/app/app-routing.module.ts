
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddTaskComponent } from './add-task/add-task.component';
import { MainViewComponent } from './main-view/main-view.component';

let routes : Routes = [
  {path:'', component:MainViewComponent},
  {path:'create', component:AddTaskComponent},
]

@NgModule({
  imports:[RouterModule.forRoot(routes)],
  exports:[RouterModule],

})
export class AppRoutingModule{

}
