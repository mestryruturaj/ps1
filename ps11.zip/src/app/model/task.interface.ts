export interface Task{
  name:string;
  description:string;
  taskStatus:string;
  created:Date;
}
