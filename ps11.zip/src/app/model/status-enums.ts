export enum TaskStatus {
  OPEN = 'Open',
  WIP = 'Work in progress',
  COMPLETED = 'Completed'
}
