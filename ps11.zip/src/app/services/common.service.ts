import { Injectable } from '@angular/core';
import { Task } from '../model/task.interface';
import { TaskStatus } from '../model/status-enums'

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  openTasks:Task[]   = [{name : 'Demo_Open', description:'', created: new Date(), taskStatus:TaskStatus.OPEN}];
  wipTasks:Task[]  = [{name : 'Demo_WorkIP', description:'', created: new Date(), taskStatus:TaskStatus.WIP}];
  completedTasks:Task[]  = [{name : 'Demo_Comp', description:'', created: new Date(), taskStatus:TaskStatus.COMPLETED}];

  constructor() { }

  addTask(task:Task):void{
    if (task.taskStatus == TaskStatus.OPEN){
      this.openTasks.push(task);
    } else if (task.taskStatus == TaskStatus.COMPLETED){
      this.completedTasks.push(task);
    } else  if (task.taskStatus == TaskStatus.WIP){
      this.wipTasks.push(task);
    }
  }
  // Setter For list
  setOpenTasks(){
    this.openTasks.map( (el:Task) => {
      el.taskStatus = TaskStatus.OPEN
    });
  }

  setWipTasks(){
    this.wipTasks.map( (el:Task) => {
      el.taskStatus = TaskStatus.WIP
    })
  }

  setCompletedTasks(){
    this.completedTasks.map( (el:Task) => {
      el.taskStatus = TaskStatus.COMPLETED
    })

  }

  // editTask :
  // 1. Delete task from existing list
  // 2. Add Task to related list
  editTask(id:number, status:string, task:Task){
    if (status == TaskStatus.OPEN){
      this.openTasks.splice(id, 1)
    } else if (status == TaskStatus.WIP){
      this.wipTasks.splice(id, 1)
    } else if ( status == TaskStatus.COMPLETED){
      this.completedTasks.splice(id, 1)
    }

    if (task.taskStatus == TaskStatus.OPEN){
      this.openTasks.push(task);
    } else if (task.taskStatus == TaskStatus.WIP){
      this.wipTasks.push(task)
    } else if (task.taskStatus == TaskStatus.COMPLETED){
      this.completedTasks.push(task)
    }
  }
}
