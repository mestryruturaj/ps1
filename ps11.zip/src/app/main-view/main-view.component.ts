import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Component, OnInit } from '@angular/core';
import { CommonService } from '../services/common.service';
import { TaskStatus } from '../model/status-enums';

@Component({
  selector: 'app-main-view',
  templateUrl: './main-view.component.html',
  styleUrls: ['./main-view.component.scss']
})
export class MainViewComponent implements OnInit {

  // Injecting Common Service
  constructor(public _cs: CommonService) { }

  ngOnInit(): void {
  }

  // onDrop : Event Handler for drop events.
  onDrop(event: CdkDragDrop<any>){
    if (event.previousContainer == event.container){
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data, event.container.data, event.previousIndex, event.currentIndex);

      this._cs.setCompletedTasks();
      this._cs.setOpenTasks();
      this._cs.setWipTasks();
    }
  }
}
